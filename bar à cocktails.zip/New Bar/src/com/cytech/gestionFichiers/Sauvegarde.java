package com.cytech.gestionFichiers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.Set;

import com.cytech.ingredients.Boisson;

public class Sauvegarde {
	  public Sauvegarde() {
	      Set<Boisson> listeDeBoissons = new HashSet<Boisson> ();
	     
	     try {
	       FileOutputStream fileOut = new FileOutputStream("Boisson.txt");
	       ObjectOutputStream out = new ObjectOutputStream(fileOut);
	       out.writeObject(listeDeBoissons);
	       out.close();
	       fileOut.close();
	       System.out.println("\nSauvegarde terminée avec succes...\n");
	 
	     } catch (FileNotFoundException e) {
	       e.printStackTrace();
	     } catch (IOException e) {
	       e.printStackTrace();
	     }
	  }
}
