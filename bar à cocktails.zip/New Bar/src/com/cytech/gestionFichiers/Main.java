package com.cytech.gestionFichiers;
import java.util.HashSet;
import java.util.Set;

import com.cytech.collections.*;
import com.cytech.ingredients.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nom;
		Set<Boisson> LDB = new HashSet<Boisson>();
		Cocktail ck = new Cocktail(LDB);
		ck.CommanderB();
	}

}
